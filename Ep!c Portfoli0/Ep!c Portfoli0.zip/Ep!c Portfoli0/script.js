let ism = prompt ("Ismingizni kiriting:");
let fam = prompt ("Familiyangizni kiritng:");
let yosh = prompt ("Yoshingizni kiriting:");

alert("Ism: " + ism + "Familiya:" + fam + " Yosh: " + yosh)
console.log("prompt + ism + fam + yosh")

let gmai = prompt ("Gmail");
let addr = prompt ("Address");

alert("Gmail:" + gmai + " Address: " + addr)
console.log("prompt + ism + fam + yosh")